package com.example.project.model;

public enum Role {
	 STUDENT,
	    ALUMNI
}
